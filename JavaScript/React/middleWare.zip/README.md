# redux-starter-kit

리덕스 스타터킷으로 사용되는 프로젝트입니다.
[Ducks 구조](https://velopert.com/3358) 가 적용된 카운터 코드가 안에 들어있습니다.
